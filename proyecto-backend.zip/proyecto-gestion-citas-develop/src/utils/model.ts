enum Especialidad {
    General = 'Medicina general',
    Cardiologia  = 'Cardiología',
    Interna = 'Medicina interna',
    Dermatologia = 'Dermatología',
    Rehabilitacion ='Rehabilitación física',
    Psicologia = 'Psicología',
    Odontologia = 'Odontología',
    Radiologia = 'Radiología'
}

export { Especialidad}